module OdaisHelper
end
