module FukyosHelper
end
