require 'test_helper'

class FukyoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
